function output = derbessel(nu,z,kind)
%DERBESSEL Takes the first derivative of the bessel functions.
%   
%   nu -  bessel order, must be an integer
%    z -  numeric array to be evaluated
% type -  character scalar of kind of bessel function, must be in the set
%         {'j','y','h','i','k'}
%
narginchk(3,3)
nargoutchk(1,1)

if ~isreal(nu) && int32(nu) ~= nu
    error("'nu' must be an integer for the bessel order.")
end

if ~isnumeric(z)
    error("'z' must be a numeric array.")
end

if ~ischar(kind) && ~isscalar(kind)
    error("'type' needs to be a single character.")
end

if all(kind ~= ['j' 'y' 'h' 'i' 'k'])
    error("'type' must be in {j,y,h,i,k}.")
end

% besselj (First Kind)
if kind == 'j'

    output = nu./z .* besselj(nu,z) - besselj(nu+1,z);

% bessel y (Second Kind)
elseif kind == 'y'

    output = nu./z .* bessely(nu,z) - bessely(nu+1,z);

% bessel h (Third Kind)
elseif kind == 'h'

    output = nu./z .* besselh(nu,z) - besselh(nu+1,z);

% bessel i (Modified First Kind)
elseif kind == 'i'

    output = nu./z .* besseli(nu,z) - besseli(nu+1,z);

% bessel k (Modified Second)
elseif kind == 'k'

    output = nu./z .* besselk(nu,z) - besselk(nu+1,z);
    
end

end