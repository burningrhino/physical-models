function output = singlestep(kz,lam,ncore,nclad,dcore,dclad)
%SINGLESTEP Summary of this function goes here
%   Detailed explanation goes here

k0 = 2*pi/lam;
k1 = k0 * ncore; % the max propagation constant
k2 = k0 * nclad;

kpcore = sqrt(k1^2 - kz.^2);
kpclad = sqrt(kz.^2 - k2^2);

bndCoreArg = kpcore * dcore/2;
bndClad1Arg = kpclad * dcore/2;
bndClad2Arg = kpclad * dclad/2;

output = - ncore^2 ./ kpcore .* besselj(1,bndCoreArg) ./ besselj(0,bndCoreArg)...
     + nclad^2 ./ kpclad .* besselk(1,bndClad1Arg) ./ besselk(0,bndClad1Arg)...
     - besselk(0,bndClad2Arg);
end

