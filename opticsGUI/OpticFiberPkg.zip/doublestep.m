function output = doublestep(kz,lam,ncore1,ncore2,nclad,dcore1,dcore2)
%DOUBLESTEP Summary of this function goes here
%   Detailed explanation goes here

k0 = 2*pi/lam;
k1 = k0 * ncore1; % the max propagation constant
k2 = k0 * ncore2;
k3 = k0 * nclad;

kpcore1 = sqrt(k1^2 - kz.^2);
kpcore2 = sqrt(k2^2 - kz.^2);
kpclad = sqrt(kz.^2 - k3^2);

bndCore1Arg = kpcore1 * dcore1/2;
bndCore2Arg = kpcore2 * dcore1/2;
bndCore3Arg = kpcore2 * dcore2/2;
bndCladArg = kpclad * dcore2/2;

M = [besselj(0,bndCore1Arg),-besselj(0,bndCore2Arg),-bessely(0,bndCore2Arg),0;
     0,besselj(0,bndCore3Arg),bessely(0,bndCore3Arg),-besselk(0,bndCladArg);
         ncore1^2 ./ kpcore1 .* derbessel(0,bndCore1Arg,'j'),...
         -ncore2^2 ./ kpcore2 .* derbessel(0,bndCore2Arg,'j'),...
         -ncore2^2 ./ kpcore2 .* derbessel(0,bndCore2Arg,'y'),...
         0;
             0,...
             ncore2^2 ./ kpcore2 .* derbessel(0,bndCore3Arg,'j'),...
             ncore2^2 ./ kpcore2 .* derbessel(0,bndCore3Arg,'y'),...
             -nclad^2 ./ kpclad .* derbessel(0,bndCladArg,'k')];

output = det(M);
end
