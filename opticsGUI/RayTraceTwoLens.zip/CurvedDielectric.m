function [rayheights,rayslopes] = CurvedDielectric(heights,angles,n1,n2,R)
%CURVEDDIELECTRIC Slopes of transmitted rays in curved dielectric medium.
% This function is used for ray-tracing impacted rays on a curved
% dielectric medium. The inputs are:
%
%   heights - numeric vector of ray heights at the dielectric
%    angles - numeric vector of ray angles at the dielectric
%        n1 - incident medium refractive index
%        n2 - transmitting medium refractive index
%         R - radius of curvature of dielectric surface (flat surfaces
%         should use Inf, convex surfaces should be negative,
%         concave surfaces should be positive)
%
% The output is outgoing / transmitted ray angles from Snell's Law.
% Remember, heights of these rays are the same as those of the 
% incident rays immediately after the curved surface.

horiz = asin(heights/R); % angle from horizontal plane to plane of incidence
incang = horiz - angles; % angles of incidence of the ray family
% note these angles are not all positive, they are WRT to the horizontal

% Snell's Law
trnsang = asin(n1 * sin(abs(incang)) / n2); % transmitted angle

% Inside lens surface
% We change the sign of the transmitted angle since we used the absolute
% value of the incident angle to use Snell's Law.
for i=1:length(trnsang)
    if sign(incang(i)) == sign(trnsang(i))
        trnsang(i) = trnsang(i) * -1;
    end
end

rayslopes = trnsang + horiz; % slope of rays inside first lens
rayheights = heights;

end

